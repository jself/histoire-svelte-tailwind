<script>
  export let Hst
</script>

<Hst.Story
  title="Cars"
  layout={{ type: 'grid', width: 200 }}
  icon="carbon:car"
  iconColor="gray"
>
  <Hst.Variant title="default">
    🚗
  </Hst.Variant>
  <Hst.Variant title="Fast">
    🏎️
  </Hst.Variant>
  <Hst.Variant title="Slow">
    🚜
  </Hst.Variant>
</Hst.Story>
