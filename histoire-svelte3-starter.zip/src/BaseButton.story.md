# BaseButton

```svelte
<BaseButton on:click={onClick}>
  Click me
</BaseButton>
```

Hello world!
