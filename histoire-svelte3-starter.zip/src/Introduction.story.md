---
group: 'top'
icon: 'carbon:bookmark'
---

# Welcome

This is a demo book using Svelte 3.

---

Learn more about Histoire [here](https://histoire.dev/).
