export default {
  plugins: {},
}
